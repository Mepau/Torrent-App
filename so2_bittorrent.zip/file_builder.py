from bitarray import bitarray
from constants import DEF_BLOCK_LENGTH
from piece_gen import gen_block
import queue
import random
import math


def breq_gen(start_offset, final_length, block_length=DEF_BLOCK_LENGTH):
    if final_length >= start_offset + block_length:
        frac, whole = math.modf((final_length - start_offset) / block_length)
        if frac:
            lblock_size = block_length * frac
            block_req = [
                (int(x), int(block_length))
                for x in range(int(final_length - lblock_size))
                if x % block_length == 0
            ]
            block_req.append((int(final_length) - int(lblock_size), int(lblock_size)))
            return block_req
        else:
            return [
                (int(x), int(block_length))
                for x in range(final_length)
                if x % block_length == 0
            ]


class FileBuilder:
    def __init__(
        self,
        bitfield: bitarray,
        filename,
        file_length: int,
        files,
        pieces_length: int,
        pieces_hash: bytes,
        recv_pieces: dict,
    ):
        self.bitfield = bitfield
        self.pieces_amount = -(-len(pieces_hash) // 20)
        self.blocks_set = (
            recv_pieces if recv_pieces else {x: [] for x in range(self.pieces_amount)}
        )
        self.filename = None
        self.files = None
        self.file_length = None
        self.pieces_length = pieces_length
        self.pieces_hash = [
            pieces_hash[x : x + 20] for x in range(len(pieces_hash)) if x % 20 == 0
        ]
        self.breq_queue = {x: queue.Queue() for x in range(self.pieces_amount)}
        self.fst_time = True

        # En caso de generar un solo archivo
        if filename and not files:
            self.filename = filename
            self.file_length = file_length
        # En caso de generar multiples archivo
        elif files:
            self.filename = filename
            self.files = files
            self.file_length = False

    def missing_blocks(self, piece_index):

        query = []
        curr_list = self.blocks_set.get(piece_index)

        if curr_list:
            # Explorar el set de piezas para descubrir todos los bloques recibidos
            for x in range(len(curr_list)):
                # Revision para el ultimo bloque
                if x != len(curr_list) - 1:
                    if curr_list[x + 1]:
                        x1_start = curr_list[x].get("block_start")
                        x1_length = curr_list[x].get("length")
                        x2_start = curr_list[x + 1].get("block_start")
                        if x1_start + x1_length == x2_start:
                            pass
                        else:
                            query.append((x1_start, x2_start))
                else:
                    if piece_index != self.pieces_amount - 1:
                        # Revisar para caso de un solo archivo
                        if self.file_length and not self.files:
                            lpiece_frac, lpiece_whole = math.modf(
                                self.file_length / self.pieces_amount
                            )

                            fblockq_start = curr_list[x].get("block_start")
                            fblockq_length = curr_list[x].get("length")

                            if lpiece_frac:
                                lpiece_size = lpiece_frac * self.file_length
                                if fblockq_start + fblockq_length == lpiece_size:
                                    pass
                                else:
                                    query.append(
                                        (fblockq_start + fblockq_length, lpiece_size)
                                    )
                            else:
                                if fblockq_start + fblockq_length == self.pieces_length:
                                    pass
                                elif (
                                    fblockq_start + fblockq_length < self.pieces_length
                                ):
                                    query.append(
                                        (
                                            fblockq_start + fblockq_length,
                                            self.pieces_length,
                                        )
                                    )
                        # Caso de multiples archivos
                        else:
                            pass
            return query
        # No hay bloques en la respectiva pieza
        else:
            if piece_index != self.pieces_amount - 1:
                query.append((0, self.pieces_length))
            # Caso de realizar un query a la ultima pieza
            elif piece_index == self.pieces_amount - 1:
                if self.file_length and not self.files:
                    lpiece_frac, lpiece_whole = math.modf(
                        self.file_length / self.pieces_amount
                    )

                    if lpiece_frac:
                        lpiece_size = lpiece_frac * self.file_length
                        query.append((0, lpiece_size))
                    else:
                        query.append((0, self.pieces_length))
                # Caso para crear req para piezas de multiples archivos
                else:
                    pass
        return query

    def secured_piece(self, piece_index):

        counter = 0

        for block in self.blocks_set[piece_index]:
            counter += block["length"] if block.get("length") else 0

        print(self.filename, self.files)
        if self.filename and not self.files:

            if piece_index < self.pieces_amount - 1:

                if counter == self.pieces_length:
                    return True

            elif piece_index == self.pieces_amount - 1:
                lpiece_frac, lpiece_whole = math.modf(
                    self.file_length / self.pieces_amount
                )
                if counter == lpiece_frac * self.pieces_length:
                    return True

        return False

    def check_4pieces(self):

        for piece_index, blocks in self.blocks_set.items():
            # Pedidos para respectiva pieza no seran generados si todavia hay pedidos pendientes en su cola
            # Lo mismo si se ha modifica el bit de la pieza debido a que ya se ha obtenido
            if self.blocks_set[piece_index] and not self.bitfield[piece_index]:
                print("hello")
                if self.secured_piece(piece_index):
                    self.bitfield[piece_index] = True
            elif (
                not self.bitfield[piece_index]
                and self.breq_queue[piece_index].qsize() == 0
            ):
                if self.fst_time:
                    if piece_index < len(self.blocks_set) - 1:
                        desired_blocks = breq_gen(0, self.pieces_length)
                        if desired_blocks:
                            random.shuffle(desired_blocks)
                            for offset, block_length in desired_blocks:
                                self.breq_queue[piece_index].put((offset, block_length))
                    elif piece_index == len(self.blocks_set) - 1:
                        # Caso para crear req para ultima piezas de un solo archivo
                        if self.file_length and not self.files:
                            lpiece_frac, lpiece_whole = math.modf(
                                self.file_length / self.pieces_amount
                            )
                            if lpiece_frac:
                                lpiece_size = lpiece_frac * self.file_length
                                desired_blocks = breq_gen(0, lpiece_size)
                                if desired_blocks:
                                    random.shuffle(desired_blocks)
                                    for offset, block_length in desired_blocks:
                                        self.breq_queue[piece_index].put(
                                            (offset, block_length)
                                        )
                            else:
                                desired_blocks = breq_gen(0, self.pieces_length)
                                if desired_blocks:
                                    random.shuffle(desired_blocks)
                                    for offset, block_length in desired_blocks:
                                        self.breq_queue[piece_index].put(
                                            (offset, block_length)
                                        )
                        # Caso para crear req para piezas de multiples archivos
                        else:
                            pass

                self.fst_time = False

    def insert_block(self, piece_index: int, block_index: int, block: bytes):

        self.blocks_set[piece_index].append(
            {"block_start": block_index, "block": block, "length": len(block)}
        )
        print(self.blocks_set[piece_index])

    def get_breq(self, piece_index: int):

        if self.breq_queue[piece_index].qsize() > 0:
            offset, block_length = self.breq_queue[piece_index].get_nowait()
            return offset, block_length
        else:
            return None, None

    def get_block(self, piece_index, start_offset, block_length):

        piece_blocks = self.blocks_set.get(piece_index)
        if piece_blocks:
            found_block = next(
                (
                    block
                    for block in piece_blocks
                    if block["block_start"] == start_offset
                ),
                None,
            )
            if found_block:
                if found_block["length"] == block_length:
                    return found_block["block"]
